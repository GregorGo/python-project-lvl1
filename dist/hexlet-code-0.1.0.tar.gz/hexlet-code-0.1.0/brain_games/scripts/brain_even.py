#!/usr/bin/env python3
"""Скрипт для запуска."""

from brain_games.even import random_game


def main():
    """Сыграть в игру на делимость."""
    random_game()


if __name__ == '__main__':
    main()
